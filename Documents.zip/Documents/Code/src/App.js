import React from 'react';
import logo from './logo.svg';
import './App.css';
import Inputstudent from './components/Inputstudent'
import Liststudent from './components/Liststudent'
function App() {
  return (
    <div>
      <Inputstudent/>
      <Liststudent/>
    </div>
  );
}

export default App;